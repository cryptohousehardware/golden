#!/usr/bin/env bash

####################################################################################
###
### Script to stop watchdog
###
####################################################################################

echo "Stopping all watchdog processes..."
pkill -f "watchdog.sh"

if [[ $? -eq 0 ]]; then
    echo "Watchdog stopped successfully"
else
    echo "Watchdog processes not found or already stopped"
fi

# Show status
ps aux | grep -v grep | grep "watchdog.sh" || echo "Watchdog is not running"

